A Pen created at CodePen.io. You can find this one at https://codepen.io/web-tiki/pen/WvNQpG.

 Menu in the shape of an hexagon. The menu items are featured on the burger click. A hover effect features title and subtitle. It uses CSS3 2D and 3D transitions. For more information about this menu see here: http://stackoverflow.com/questions/29717765/animated-hexagon-menu/29721362#29721362